


*** my_blog ***

My_blog is a simple system of adding, editing and deleting comments

I uses codeigniter framework and add simple
jquery functions

I utilize bootstrap and html as a frontend

I also share my database (blog_db) so please add it to the server.

Credentials:

Admin
username : Jane
password : janjan

User
username : Janjan
password : janjan

Please do love my work, thank you!